<?php

$useragent = "Mozilla/5.0 (Linux; Android 8.1.0; Redmi 6A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36";

$cookie = "bitmedia_fid=eyJmaWQiOiJmOTUxN2NmNjljMTY3ZDMwMzBiOTlhZjM5NjM1ZGQ5MiIsImZpZG5vdWEiOiJlNTg1NWQ1MmViY2ZlOGE2ZmUwOWI2MDhkYTg4YjBhZSJ9;dom3ic8zudi28v8lr6fgphwffqoz0j6c=0b3f8862-deed-4354-9bf7-25b3bba4de9c%3A1%3A1;_ga=GA1.2.57778146.1631507020;_gid=GA1.2.866788538.1631507020;sb_main_67e8c5c376ff7e107f70ff550ed46f6b=1;csrf_cookie_name=196fca554beac28072cfaa261f634ea0;sb_count_67e8c5c376ff7e107f70ff550ed46f6b=4;ci_session=d66657c86958116af773e334832b4b8b3acab884;_gat_gtag_UA_178497691_1=1;zone-cap-4422200=1";

//wallet faucetpay tanpa @gmail.com
$fp = "yzzztv.officialyt";

//coin untuk auto wd
//BTC : 1   LTC : 2   DOGE : 3
//DASH : 4  USDT : 5   TRX : 6
$coin = "6";